# selenium-test-automation
Necessary tools:
- Java 17
- Maven 3+
