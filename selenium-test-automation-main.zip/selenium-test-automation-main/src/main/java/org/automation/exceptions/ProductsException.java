package org.automation.exceptions;

public class ProductsException extends RuntimeException {
    public ProductsException(String message) {
        super(message);
    }
}
